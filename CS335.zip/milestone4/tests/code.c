long int na=9;
// int sum(long int a, long int b,long int c,long int d,long int e,long int f,long int g,long int i,long int o){
//     int s=a+b+c+d+e+f+g;
//     return my(1);
// }
// int my(int a){
//     sum(1,2,3,4,5,6,7,7,7);
//     int b=1;
// 	return b;
// }
#include <stdio.h>

int main(){
    long int n=1;
    long int arr[10];
    arr[n]=0;
    return arr[n];
}

/*

base
base - 4
base - 8     f = 7
base - 12    c = 8
base - 16    b = 3
base - 20    a = 4

*/
