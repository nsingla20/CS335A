class GFG {

    static int sum(int a, int b){

        return 0;
    }

    static void main() {
        // int **array;
        // int a = 2;
        // array = (int **)malloc(20 * sizeof(int *));
        // for (int i = 0; i < 20; i++) {
        //     array[i] = (int *)malloc(20 * sizeof(int));
        // }
        // int arr[] = new int[5][5];

        // arr[3][3] = 4;
        // int y = 69,z=12,m=12,n=2;
        int x = sum(1,2);
        // int a= sum(1,2);
        // System.out.println(a);
    }
}
