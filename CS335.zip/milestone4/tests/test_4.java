// Generic
class Main {
	public static void main(int args)
	{
		int a, b=1;
		float c=5;
		char d=10;
		boolean e=9;
		a = 10 + b*c - d;
		if (a > b) {
			a = a + b * a + b;
		}
		System.out.println(a);
		if (a + 15 < b) {
			a = a + b * a + b;
		}
	}
}
