class Bike{
    void run(){
        System.out.println(1);
    }
}

class Splendor{
    void run(){
        System.out.println(0);
    }
}

class DynamicPoly {
    public static void main(String[] args) {
        Bike.run();
    }
}
