// Generic
class Main {
	public static void main(String[] args)
	{
		int a, b;
		float c;
		char d;
		boolean e;
		a = 10 + b*c - d;
		if (a > b) {
			a = a + b * a + b;
		}
		System.out.println(a);
		if (a + 15 < b) {
			a = a + b * a + b;
		}
	}
}
